﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gs_GameIn : GameState {

	// Use this for initialization
	new void Start () {
		
	}
	
	// Update is called once per frame
	new void Update () {
		
	}
}
